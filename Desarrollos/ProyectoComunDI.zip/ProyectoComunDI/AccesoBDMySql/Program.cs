﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AccesoBDMySql;

namespace AccesoBDMySql
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * Lista donde cargaremos los datos
            List<string[]> dataseti = new List<string[]>();
            funcion para cargar los datos, hay que pasarle la cadena de conexion a la base de datos.
            dataseti = Dataset.cargarDatos("127.0.0.1", "3306", "root","", "dataset");
            repetitiva para mostrar-guardar-ejecutar datos
            foreach(string[] row in dataseti)
            {
                Console.WriteLine(row[0] + " " + row[1] + " " + row[2] + " " + row[3] + " " + row[4]);
            }

            Console.ReadKey();
            */

        }
    }
}
