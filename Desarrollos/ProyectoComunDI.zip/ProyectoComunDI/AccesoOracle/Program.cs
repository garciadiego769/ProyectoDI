﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data.Common;

namespace AccesoOracle
{
    class Program
    {

        private const string V = "User Id=SYSTEM;Password=12345Abcde;";
        static void Main(string[] args)
        {
            bool datos = ConsultaDatos.AccesoBDOracle();
            ;
          /*  string oradb = "Data Source=(DESCRIPTION="
             + "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=PC-DIEGO)(PORT=1521)))"
             + "(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=XE)));"
             + V;
            OracleConnection conexion = new OracleConnection(oradb);

            conexion.Open();
            Console.WriteLine("Connected to Oracle" + conexion.ServerVersion);

            //SELECT
            string sql = "select * from DANIDIEGO.ATRIBUTOSFLORES";
            OracleCommand cmd = new OracleCommand();
            cmd.CommandText = sql;
            cmd.Connection = conexion;

            using (DbDataReader reader = cmd.ExecuteReader())
            {
                if (reader.HasRows)
                {

                    while (reader.Read())
                    {
                        int numeroEvidencia = reader.GetInt32(1);
                        Console.WriteLine("Numero de Evicencia: " + numeroEvidencia.ToString());

                        double longitudPetalo = reader.GetDouble(2);
                        Console.WriteLine("Longitud Pétalo: " + longitudPetalo.ToString("0.00"));

                        double longitudSepalo = reader.GetDouble(3);
                        Console.WriteLine("Longitud Sépalo: " + longitudSepalo.ToString("0.00"));

                        double anchoPetalo = reader.GetDouble(4);
                        Console.WriteLine("Ancho Pétalo: " + anchoPetalo.ToString("0.00"));

                        double anchoSepalo = reader.GetDouble(5);
                        Console.WriteLine("Ancho Sépalo: " + anchoSepalo.ToString("0.00"));

                        string tipoFlor = reader.GetString(6);
                        Console.WriteLine("Tipo Flor: " + tipoFlor);

                        Console.WriteLine("---------------------------------");
                    }
                }

            }
            Console.Read();*/
        }

       
    }

}
