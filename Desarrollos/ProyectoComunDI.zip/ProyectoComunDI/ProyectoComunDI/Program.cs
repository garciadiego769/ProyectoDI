﻿using AccesoOracle;
using System;
using System.Data.Common;

namespace ProyectoComunDI
{

    class Program
    {
        
        static void Main(string[] args)
        {
            //Console.WriteLine("Hola Mundo");

            #region Acceso MySQL

            // cread una region cada uno con un ejemplo de como se accedea vuestra libreria

            #endregion

            #region Acceso Oracle
            bool datos = ConsultaDatos.AccesoBDOracle();
            ;
            #endregion

        }
    }
}
